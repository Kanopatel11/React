import logo from './logo.svg';
import './App.css';
import Fetchdata from './Fetchdata';
import img from './img.jpg'

function App() {
  return (
    <Fetchdata Image={img}/>
  );
}

export default App;
