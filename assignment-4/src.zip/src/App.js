import logo from './logo.svg';
import './App.css';
import Logged from './Logged';

function App() {
  return (
    <>
    <Logged />
    </>
  );
}

export default App;