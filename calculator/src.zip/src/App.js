import logo from './logo.svg';
import './App.css';
import Caculator from './Caculator';

function App() {
  return (
    <Caculator/>
  );
}

export default App;
