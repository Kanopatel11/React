import logo from './logo.svg';
import './App.css';
import Cont from './Cont';
import Uncont from './Uncont';

function App() {
  return (
    <>
    <Cont/>
    <Uncont/>
    </>
  );
}

export default App;
