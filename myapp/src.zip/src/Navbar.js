import React from 'react'

function Navbar() {
  return (
    <>   
     <header>
        <div className="inheader">
  
         <div className="logo">
            <img src="img/logo.png" alt=""/>
  
         </div>
        <nav>
         
                    <a href="">Home</a>
                    <a href="">Servise</a>
                    <a href="">Order Now</a>
                    <a href="">Contact us</a>
                <button> Order now</button>
  
        </nav>
         </div>
         <div className="text1">
            <img src="img/pizz2.jpg" alt=""/>
         </div>
        
  </header>
  <section className="parent">
          <div className="text2">
            <div className="col">
               <h5> THE</h5>
               <h2>​🇵​​🇮​​🇿​​🇿​​🇦​ ​🇸​​🇭​​🇴​​🇵​</h2>
               <button>Order Online </button>
           </div>
           </div>          
  </section>
  <section className="text3">
         <div className="col1">
              <h6>OUR STORY</h6>
              <h1>THE PASSION FOR PIZZA</h1>
              <div>
               <img src="img/man1.webp" alt=""/>
            </div>
           <div>
            <p>I'm a paragraph. Click here to add your own text and edit me. It’s easy. Just click “Edit Text” or <br/>double click me to add your own content and make changes to the font. Feel free to <br/> drag and drop me anywhere you like on your page. I’m a great place for you to tell a story and let your <br/> users know a little more about you.</p>
           </div>
         </div>
           
           
  </section>
  <section className="text4">
           <div className="main">
               <div className="main1"><img src="img/p1.jpg" alt=""/></div>
               <div className="main1"><img src="img/p2.jpg" alt=""/></div>
               <div className="main1"><img src="img/p3.jpg" alt=""/></div>
               <div className="main1"><img src="img/p4.jpg" alt=""/></div>
               <div className="main1"><img src="img/p5.jpg" alt=""/></div>
               <div className="main1"><img src="img/p6.jpg" alt=""/></div>
               <div className="main1"><img src="img/p7.jpg" alt=""/></div>
               <div className="main1"><img src="img/p8.jpg" alt=""/></div>

           </div>
           <div className="child">
            <button>Load More</button>
           </div>
  </section>
  <section className="text5">
    <div className="col3"> 
          <h1>FANCY A PIZZA PARTY?</h1>
          <p>I'm a paragraph. Click here to add your own text and edit me. It’s easy. Just click “Edit <br/> Text” or double click me to add your own content and make changes to the font. <br/> Feel free to drag and drop me anywhere you like on your page. I’m a great place for you to <br/> tell a story and let your users know a little more about you.

          </p>
          <button>Contact Us</button>
    </div>

  </section>
  <section className="text6">

<div className="col4">
    <h2>𝗛𝗼𝘄 𝗱𝗼𝗲𝘀 𝗶𝘁 𝘄𝗼𝗿𝗸</h2>

</div>
<div className="col5">
    <div className="a"> 
         <img src="img/location1.svg" alt=""/>
         <h6>Select location</h6>
         <p>Choose the location where <br/> your food will be delivered.</p>
        
    </div>
    
    <div className="a">
       <img src="img/icon2.svg" alt=""/>
       <h6>Choose order</h6>
       <p>Check over hundreds of  <br/>menus to pick your <br/> favorite food</p>
    </div>
    <div className="a">
      <img src="img/icon3.svg" alt=""/>
      <h6>Pay advanced</h6>
      <p>It's quick, safe, and simple. <br/> Select several methods of payment</p>
    </div>
    <div className="a">
         <img src="img/icon4.svg" alt=""/>
         <h6>Enjoy meals</h6>
         <p>Food is made and delivered directly to your home.</p>
    </div>
      

</div>
          
  </section>
  <section className="text7">
   <div className="col6">
      <h2>𝗣𝗼𝗽𝘂𝗹𝗮𝗿 𝗶𝘁𝗲𝗺𝘀</h2>
   </div>
   <div className="col7">
    <div className="b">
      <img src="img/p11.jpg" alt=""/>
        <h6>𝗗𝗼𝘂𝗯𝗹𝗲 𝗰𝗵𝗲𝗲𝘀𝗲 𝗠𝗮𝗿𝗴𝗵𝗲𝗿..
        </h6>
        <h5>𝗥𝘀 𝟭𝟱𝟱</h5>
    </div>
    <div className="b">
      <img src="img/p12.jpg" alt=""/>
      <h6>𝗙𝗮𝗿𝗺 𝗙𝗿𝗲𝘀𝗵 𝗽𝗶𝘇𝘇𝗮</h6>
      <h5>𝗥𝘀 𝟭𝟳𝟱</h5>
    </div>  
    <div className="b">
      <img src="img/p13.jpg" alt=""/>
      <h6>𝗣𝘂𝗻𝗷𝗮𝗯 𝗗𝗮 𝗣𝗮𝗻𝗲𝗲𝗿 𝗧𝗮𝗱𝗸𝗮</h6>
      <h5>𝗥𝘀 𝟮𝟮𝟬</h5>
    </div>
    <div className="b">

      <img src="img/p14.jpg" alt=""/>
      <h6>𝟵 𝗖𝗵𝗲𝗲𝘀𝘆 𝗣𝗶𝘇𝘇𝗮 </h6>
      <h5>𝗥𝘀 𝟮𝟯𝟬</h5>
    </div>
    <div className="b">
      <img src="img/p15.jpg" alt=""/>
      <h6>𝗣𝗲𝗿𝗶 𝗣𝗲𝗿𝗶 𝗣𝗶𝘇𝘇𝗮</h6>
      <h5>𝗥𝘀 𝟮𝟱𝟬</h5>
    </div>

   </div>
  </section>
  <section className="text8">
    <div className="col8">
     <img src="img/m1.jpg" alt=""/>
    </div>
    <div className="col9">
    
       <h1>𝟰𝟱 % 𝗢𝗙𝗙 </h1>
       
    
    </div>

  </section>

  <footer>
    <div className="text11">
             <div className="b">
               <h1>Quick Link</h1> <br/><br/>
               <a href="">About us</a><br/><br/>
               <a href="">Tems & condition</a><br/><br/>
               <a href="">Privarcy policy</a><br/><br/>
               <a href="">Help</a><br/><br/>
               <a href="">Tour</a>
             </div>
             <div className="b">
               <h1>Support</h1> <br/><br/>
               <a href="">Our Location</a><br/><br/>
               <a href="">The Host</a><br/><br/>
               <a href="">About</a><br/><br/>
               <a href="">Contact</a><br/><br/>
               <a href="">News</a>
             </div>
             <div className="b">
               <h1>Contact info</h1> <br/><br/>
               <a href="">98 West 21 th street</a><br/><br/>
               <a href="">New York NY 2016</a><br/><br/>
               <a href="">+(123)-456-789</a><br/><br/>
               <a href="">+(123)-456-789</a><br/><br/>
               <a href="">info@mydomain.com</a>
             </div>
             <div className="b">
               {/* <h1>Contact </h1><br/><br/>
               <i className="fa fa-facebook-square"></i>   
               <i className="fa fa-instagram"></i>   
               <i className="fa fa-pinterest"></i>   
               <i className="fa fa-twitter"></i>    */}
               
             </div><hr/>

    </div>  
</footer>
<section className="text12">
<h1>Contact by : kano patel </h1>
</section>

</>

  )
}

export default Navbar