import React from 'react'

function Section1() {
  return (
    <section className="parent">
          <div className="text2">
            <div className="col">
               <h5> THE</h5>
               <h2>​🇵​​🇮​​🇿​​🇿​​🇦​ ​🇸​​🇭​​🇴​​🇵​</h2>
            
           </div>
           </div>          
  </section>
  )
}

export default Section1