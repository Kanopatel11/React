import logo from './logo.svg';
import './App.css';
import Fetchdata from './Fetchdata';

function App() {
  return (
    <>
     <Fetchdata/>
    
    
    </>
  );
}

export default App;
