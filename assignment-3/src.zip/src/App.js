import logo from './logo.svg';
import './App.css';
import Counter from './Counter';
import Img from './image.jpg'


function App() {
  return (
       <Counter Back={Img}  />
  );
}


export default App;
